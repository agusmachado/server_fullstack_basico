import express from 'express' // Framework para crear servidores web
import router from './router'
import cors from 'cors'

const app = express() // Creamos una nueva app de Express (nuestro servidor backend)

// CORS - El frontend viaja hacia el puerto 3000 (que es el backend) y, en el server a través de cors le abren la puerta al puerto 5173
// Este mecanismo se necesita cuando estamos en Desarrollo
app.use(cors({
    origin: "http://localhost:5173", // Permitimos que solo este origen pueda hacer pedidos al backend
    methods: ['GET', 'POST']
}))


app.use(express.json())
/* 
    Desde el frontend sale una petición. Esa petición llega al server y pasa por express.json()
    expres.json() hace que esa petición sea legible.
    El sistema procesa esa petición con prisma y, ahí, decide que hacer con esa petición.

    Ejemplo:
    {
        "name": "Lapicera",
        "price": 10
    }

    El middleware express.json() lee el body y lo convierte a un objeto JavaScript.
    Ahora podemos hacer req.body.name y obtener "Lapicera"
*/

app.use('/api/products', router)

// 404 - "Not Found": se ejecuta si ninguna ruta contesta
app.use((req, res, _next) => {
    res.status(404).json({
        error:'No encontrado - Not Found',
        path: req.originalUrl, // Ruta que intentaron acceder
        method: req.method
    })
})


// ---- Manejador de errores GLOBAL (500 y otros)
app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error('Error Handler :', err)
    const isDev = process.env.NODE_ENV !== 'production'

    const payload: Record<string, unknown> = {
        error: 'Internal server error',
        tip: 'Revisá la consola del servidor para más detalles'
    }

    // Si estamos en desarrollo agregamos más detalles técnicos
    if (isDev) {
        payload.details = {
            message: err?.message,
            stack: err?.stack
        }
    }

    // Elegimos el status HTTP:
    const status = typeof err?.status === 'number' ? err.status: 500

    // Enviamos la respuesta JSON al cliente con el status
    res.status(status).json(payload)
})

export default app