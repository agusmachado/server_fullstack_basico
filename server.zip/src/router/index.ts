import { Router } from "express"
import { crearProducto, editarProducto, listaProductos } from "../controllers/productController"
import { validateBody } from "../middleware/validate"
import { ProductCreateSchema, ProductPatchSchema } from "../validators/product.schema"

const router = Router()

// Rutas

router.get('/', listaProductos)

router.post('/', validateBody(ProductCreateSchema), crearProducto)

router.patch("/:id", validateBody(ProductPatchSchema), editarProducto)

router.delete('/', (req, res) => {    
    res.json("Desde DELETE")
})

export default router 